﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MediaFootballGame
{
    public partial class Form : System.Windows.Forms.Form
    {
        private Point position;
        private bool dragging, lose = false;
        private int countCoins = 0;
        public Form()
        {
            InitializeComponent();
            bg1.MouseDown += MouseClickDown;
            bg1.MouseUp += MouseClickUp;
            bg1.MouseMove += MouseClickMove;
            bg2.MouseDown += MouseClickDown;
            bg2.MouseUp += MouseClickUp;
            bg2.MouseMove += MouseClickMove;
            labelLose.Visible = false;
            btnRestart.Visible = false;
            KeyPreview = true;
        }
        private void MouseClickDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            position.X = e.X;
            position.Y = e.Y;
        }
        private void MouseClickUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }
        private void MouseClickMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point currentPoint = PointToScreen(new Point(e.X, e.Y));
                this.Location = new Point(currentPoint.X - position.X, currentPoint.Y - position.Y + bg1.Top);
            }
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Escape)
                this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }


        private void timer_Tick(object sender, EventArgs e)
        {
            int speed = 10;
            bg1.Top += speed;
            bg2.Top += speed;
            int carSpeed = 7;
            brokeBoys.Top += carSpeed;
            twoDrots.Top += carSpeed;
            coin.Top += carSpeed;
            if (coin.Top >= 640)
            {
                coin.Top = -50;
                Random random = new Random();
                coin.Left = random.Next(150, 560);
            }

            if (player.Bounds.IntersectsWith(coin.Bounds))
            {
                countCoins++;
                labelCoin.Text = "Монеты: " + countCoins.ToString();
                coin.Top = -50;
                Random random = new Random();
                coin.Left = random.Next(150, 560);
            }


            if (bg1.Top >= 640)
            {
                bg1.Top = 0;
                bg2.Top = -640;
            }

            if (brokeBoys.Top > 650)
            {
                brokeBoys.Top = -130;
                Random random = new Random();
                brokeBoys.Left = random.Next(150, 300);
            }
            if (twoDrots.Top > 650)
            {
                twoDrots.Top = -400;
                Random random = new Random();
                twoDrots.Left = random.Next(300, 560);
            }

            if (player.Bounds.IntersectsWith(brokeBoys.Bounds) || player.Bounds.IntersectsWith(twoDrots.Bounds))
            {
                timer.Enabled = false;
                labelLose.Visible = true;
                btnRestart.Visible = true;
                lose = true;
            }

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (lose) return;
            int speed = 10;
            if ((e.KeyCode == Keys.A || e.KeyCode == Keys.Left)&& player.Left > 150)
            {
                player.Left -= speed;
            }
            else if ((e.KeyCode == Keys.D || e.KeyCode == Keys.Right) && player.Right < 700)
            {
                player.Left += speed;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            brokeBoys.Top = -130;
            twoDrots.Top = -400;
            labelLose.Visible = false;
            btnRestart.Visible = false;
            timer.Enabled = true;
            lose = false;
            countCoins = 0;
            labelCoin.Text = "Монеты: " + countCoins.ToString();
            coin.Top = -500;
        }

    }
}
